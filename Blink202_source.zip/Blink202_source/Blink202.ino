/*
  Blink LEDs
*/
#include <avr/sleep.h>

const uint8_t LEDs = 5;
const uint8_t LED[] = {0, 1, 2, 3, 4}; 
int Mode = 0;
const uint32_t wokingTime = 180000;  // 3分でスリープ
//const uint32_t wokingTime = 60000;  // 1分でスリープ
unsigned long tm = 0;

//the interrupt is handled after waking up here
ISR(PORTA_PORT_vect) {
  PORTA.INTFLAGS = PORT_INT0_bm; //clear the interrupt flag on PAn
}

// the setup function runs once when you press reset or power the board
void setup() {
  // initialize digital pin LED_BUILTIN as an output.
  for (uint8_t i=0; i<LEDs; i++)
  {//LED pin reset
    pinMode(LED[i], OUTPUT);
    digitalWrite(LED[i], LOW);
  }
  //MODE pin reset
  pinMode(PIN_PA0, INPUT_PULLUP);
  tm = millis() + wokingTime;
}

// the loop function runs over and over again forever
void loop() {
  switch(Mode)  {
    case 0:
      LED_0();
      break;
    case 1:
      LED_1();
      break;
    case 2:
      LED_2();
      break;
    case 3:
      LED_3();
      break;
    default:
      break;
  }
  //MODE pin read
  Btn_read();

  //Sleep timer check
  if(tm < millis()) {
      for(uint8_t i=0; i<LEDs; i++) { 
        digitalWrite(LED[i], LOW);
      }
      goSleep();
  }
}

void goSleep() {//Goto sleep
  set_sleep_mode(SLEEP_MODE_PWR_DOWN); //select the power down sleep mode
  noInterrupts(); //disable all interrupts
  sleep_enable();
  interrupts(); //enable all interrupts
  PORTA.PIN0CTRL = PORT_PULLUPEN_bm | PORT_ISC_LEVEL_gc; //pull up PAn, trigger on low level
  sleep_cpu(); //actually go to sleep here

  //the program will continue after waking up from here
  sleep_disable();
  PORTA.PIN0CTRL = PORT_PULLUPEN_bm; //pull up PAn, turn off the pin change interrupt
  tm = millis() + wokingTime;
}

void LED_0()
{// LED bright circle
  for (uint8_t i=LEDs; i>0; i--)
  {
    digitalWrite(LED[i-1], HIGH);
    delay(60);
    digitalWrite(LED[i-1], LOW);
    //delay(10);
  }
}

void LED_1()
{// LED bright random
  for (uint8_t i=0; i<LEDs; i++)
  {
    digitalWrite(LED[i], random(2));
  }
  delay(400);
}

void LED_2()
{// LED bright wipe
  analogWrite(LED[0], LOW);
  for (uint8_t j=0; j<255; j++)
  {
    for (uint8_t i=1; i<LEDs; i++)
    {
      analogWrite(LED[i], j);
    }
  delay(5);
  }
  Btn_read();
  for (uint8_t j=255; j>0; j--)
  {
    for (uint8_t i=1; i<LEDs; i++)
    {
      analogWrite(LED[i], j);
    }
  delay(5);
  }
}

void LED_3()
{// LED bright full
  for (uint8_t i=0; i<LEDs; i++)
  {
    digitalWrite(LED[i], HIGH);
  }
  delay(100);
}

void Btn_read()
{//MODE pin read
  if (digitalRead(PIN_PA0) == LOW)   {
  Mode ++;
  if(Mode > 3) {
    Mode = 0;
    delay(500);
    }
  }
}